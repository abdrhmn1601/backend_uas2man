<?php

return $reply = [
    'status' => false,
    'error' => [],
    'data' => []
];